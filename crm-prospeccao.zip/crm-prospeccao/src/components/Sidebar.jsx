const NAV_ITEMS = [
  { id: "dashboard", icon: "▣", label: "Dashboard" },
  { id: "leads", icon: "◈", label: "Leads" },
  { id: "pipeline", icon: "◎", label: "Pipeline" },
  { id: "relatorios", icon: "◆", label: "Relatórios" },
  { id: "configuracoes", icon: "⚙", label: "Configurações" },
];

export default function Sidebar({ open, onClose, activeView, setActiveView }) {
  return (
    <>
      {open && <div className="sidebar-backdrop" onClick={onClose} />}
      <aside className={`sidebar ${open ? "open" : ""}`}>
        <div className="sidebar-logo">
          <div className="logo-dot" />
          <span className="logo-text">ProspectFlow</span>
          <button className="sidebar-close" onClick={onClose}>✕</button>
        </div>

        <nav className="sidebar-nav">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              className={`nav-item ${activeView === item.id ? "active" : ""}`}
              onClick={() => { setActiveView(item.id); onClose(); }}
            >
              <span className="nav-icon">{item.icon}</span>
              <span className="nav-label">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="sidebar-footer">
          <div className="user-info">
            <div className="avatar">JD</div>
            <div>
              <p className="user-name">João Developer</p>
              <p className="user-plan">Plano Pro</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
