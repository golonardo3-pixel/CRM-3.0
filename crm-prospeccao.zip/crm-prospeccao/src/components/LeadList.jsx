import { useState } from "react";
import LeadCard from "./LeadCard";

const STATUS_FILTERS = ["Todos", "Novo", "Contatado", "Respondeu", "Negociação", "Fechado"];

export default function LeadList({ leads, statusOptions, onStatusChange, onViewDetails }) {
  const [filter, setFilter] = useState("Todos");
  const [search, setSearch] = useState("");

  const filtered = leads.filter((l) => {
    const matchStatus = filter === "Todos" || l.status === filter;
    const matchSearch =
      l.empresa.toLowerCase().includes(search.toLowerCase()) ||
      l.nicho.toLowerCase().includes(search.toLowerCase()) ||
      l.cidade.toLowerCase().includes(search.toLowerCase());
    return matchStatus && matchSearch;
  });

  return (
    <section className="lead-section">
      <div className="lead-section-header">
        <h2 className="section-title">Leads <span className="count-badge">{filtered.length}</span></h2>
        <div className="search-box">
          <span className="search-icon">⌕</span>
          <input
            type="text"
            placeholder="Buscar empresa, nicho, cidade..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="search-input"
          />
        </div>
      </div>

      <div className="filter-tabs">
        {STATUS_FILTERS.map((s) => (
          <button
            key={s}
            className={`filter-tab ${filter === s ? "active" : ""}`}
            onClick={() => setFilter(s)}
          >
            {s}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">◈</div>
          <p>Nenhum lead encontrado</p>
        </div>
      ) : (
        <div className="lead-grid">
          {filtered.map((lead) => (
            <LeadCard
              key={lead.id}
              lead={lead}
              statusOptions={statusOptions}
              onStatusChange={onStatusChange}
              onViewDetails={onViewDetails}
            />
          ))}
        </div>
      )}
    </section>
  );
}
